<?php
$liczba1 = 5;
$liczba2 = 6;
$wynik = $liczba1 + $liczba2;
echo $wynik;
?>