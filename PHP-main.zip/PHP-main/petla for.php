<?php
for($i=0; $i < 100; $i++){
    if
echo $i ."<br>";
}
?>
