document.write("ostatnia modyfikacja strony".fontcolor("red").bold().fontsize(7)+"<br>");
document.write(document.lastModified)